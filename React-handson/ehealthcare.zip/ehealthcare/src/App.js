import './App.css';
import {BrowserRouter,Route,Routes,NavLink} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Navbar from './component/Navbar';
import Admin from './component/Admin';


function App() {
  return (
    <div className='App'>
        <Navbar/>

    </div>
  );
}

export default App;
