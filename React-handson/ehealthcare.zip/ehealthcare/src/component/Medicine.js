import React, { Component } from 'react';
import Navbar from './Navbar';
import { Variables } from './Variable';



export class Medicine extends Component{
    constructor(props){
        super(props)

        this.state={
            medicines:[],
            PhotoPath:Variables.PHOTO_URL,
            MedicineName:"",
            withoutfilter:[]
        }

    }

    Filter()
    {
        var MedicineName = this.state.MedicineName;
        var filtereddata = this.state.withoutfilter.filter(
            function(fl){
                return fl.med_name.toString().toLowerCase().includes(
                    MedicineName.toString().trim().toLowerCase()
                )
            }
        );
        this.setState({medicines:filtereddata});

    }

    changeMedicineName = (e) =>{
        this.state.MedicineName = e.target.value;
        this.Filter();
    }

    refreshlist(){
        fetch(Variables.API_URL+'Medicine')
        .then(response=>response.json())
        .then(data=>{
            this.setState({medicines:data,withoutfilter:data});
        });
    }

    componentDidMount(){
        this.refreshlist();
    }

    render(){
        const
        {
            medicines,
            PhotoPath
        }=this.state;
        return(
            <div className='App'>
                <Navbar/>
                <div>
                    <table className='table table-stripped'>
                        <thead>
                            <tr>
                                <th>
                                    <input className='form-control m-2' 
                                    onChange={this.changeMedicineName} 
                                    placeholder="Filter"/>
                                    Name
                                </th>
                                <th>
                                    Price
                                </th>
                                <th>
                                   Image
                                </th>
                                <th>
                                    Seller
                                </th>
                                <th>
                                    Descrpition
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {medicines.map(med =>
                                <tr key={med.med_id}>
                                    <td>
                                        {med.med_name}
                                    </td>
                                    <td>
                                        {med.med_price}
                                    </td>
                                    <td>
                                        <img height='150px' src={PhotoPath+med.med_image}/>
                                    </td>
                                    <td>
                                        {med.med_seller}
                                    </td>
                                    <td>
                                        {med.med_description}
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }    
}
