import React from 'react';
import { Link } from 'react-router-dom';

const Navbar =() =>{
    return(
        <div >
            <nav className='navbar navbar-expand-sm bg-light navbar-dark'>
              <ul className='navbar-nav'>
                <li className='nav-item m-1'>
                    <Link className='btn btn-light btn-outline-primary' to='/'>Home</Link>
                </li>
                <li className='nav-item m-1'>
                    <Link className='btn btn-light btn-outline-primary' to='/medicine'>Medicine</Link>
                </li>
              </ul>
            </nav>
        </div>
    )
}
export default Navbar