export const Variables={
    API_URL:"https://localhost:7204/api/",
    PHOTO_URL:"https://localhost:7204/Photos/"
}