import React from 'react';
import { Link } from 'react-router-dom';

const Navbar =() =>{
    return(
        <div >
            <nav className='navbar navbar-expand-sm bg-dark navbar-dark'>
                <img width='50px' src='https://www.citypng.com/public/uploads/small/11639359975ggq2okxvvicnlkcuhtavyxrxhtf99gbgnlqpbyj60fqojukgfgmllsl49o25cdepykokp0mz1apslqfl4bo8am4ydusszvzsqau9.png' />
                    <h2 style={{color:"white",paddingRight:"20px"}}>AbcHealthcare</h2>
            
              <ul className='navbar-nav'>
                
                <div>
                <li className='nav-item m-1'>
                    <Link className='btn btn-success btn-outline-light' to='/admin'>Admin</Link>
                </li>
                </div>
                {/* <div>
                <li className='nav-item m-1'>
                    <Link className='btn btn-primary btn-outline-light' to='/'>User</Link>
                </li>
                </div> */}
                <div>
                <li className='nav-item m-1'>
                    <Link className='btn btn-primary btn-outline-light' to='/login'>Login</Link>
                </li>
                </div>
              </ul>
              <h5 align="right" style={{color:"white",textAlign:"right",paddingLeft:'700px'}}>Helpline No : 1800-1800-999</h5>
            </nav>
        </div>
    )
}
export default Navbar