import Navbar from "./Navbar";

export default function PayNow(){
    return(
        <div>
            <Navbar/>
        <br/>
        <h3 align="center">
        <img src="https://cdn.dribbble.com/users/1121009/screenshots/5266246/dribbble_17.jpg" height="300px"/>
        </h3>
        <br/>
        <h3 align="center">Thank you for shopping with us !!</h3>
        <br/>
        <h5 align="center"> Your order will be dilivered in 2-3 days.</h5>
        <br/>
        <br/>
        <br/>
        <h5 align="center">
        <a href="/" class="btn btn-primary btn-sm float-right"><span className="pay-btn">Back to Store</span></a>
        </h5>
    </div>
    )
}